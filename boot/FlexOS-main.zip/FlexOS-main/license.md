Nova OS License Agreement

You agree to the [Adthoughtsglobal Nova Terms of use](https://github.com/adthoughtsglobal/Nova-OS/blob/634dc3a41c77c661cf725b85ea8ba71d27aeae0e/Adthoughtsglobal%20Nova%20Terms%20of%20use)
